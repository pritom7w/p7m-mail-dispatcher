package com.p7m.mailsender

import android.content.Intent
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val webView = findViewById<WebView>(R.id.loginWebView)
        val btnProceed = findViewById<Button>(R.id.btnProceedToCampaign)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.contains("mail.google.com") == true || url?.contains("myaccount.google.com") == true) {
                    SessionManager.saveLoginState(this@LoginActivity, "authenticated_user@gmail.com")
                    Toast.makeText(this@LoginActivity, "Login detected! Ready for campaign.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Load Gmail login web interface
        webView.loadUrl("https://accounts.google.com/ServiceLogin?service=mail")

        btnProceed.setOnClickListener {
            if (SessionManager.isLoggedIn(this)) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Please log into your Gmail account in the browser first.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
