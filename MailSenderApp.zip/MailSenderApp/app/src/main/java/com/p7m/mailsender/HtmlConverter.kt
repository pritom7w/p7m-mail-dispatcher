package com.p7m.mailsender

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

enum class AttachmentType(val label: String, val extension: String, val mimeType: String) {
    BODY_HTML("Body HTML (No Attachment)", "html", "text/html"),
    PDF("Standard Vector PDF", "pdf", "application/pdf"),
    IMAGE_PDF("Image PDF (Rasterized)", "pdf", "application/pdf"),
    JPEG("JPEG Image", "jpg", "image/jpeg"),
    PNG("PNG Image", "png", "image/png"),
    HTML_FILE("HTML File Attachment", "html", "text/html")
}

object HtmlConverter {

    fun resolveFileName(customName: String, isAuto: Boolean, type: AttachmentType): String {
        val baseName = if (isAuto || customName.isBlank()) {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val rand = UUID.randomUUID().toString().take(5).uppercase()
            "INV_${stamp}_$rand"
        } else {
            customName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        }
        return if (baseName.endsWith(".${type.extension}", ignoreCase = true)) {
            baseName
        } else {
            "$baseName.${type.extension}"
        }
    }

    suspend fun convertHtmlToFile(
        context: Context,
        htmlContent: String,
        type: AttachmentType,
        fileName: String
    ): File? = withContext(Dispatchers.Main) {
        if (type == AttachmentType.BODY_HTML) return@withContext null

        val outputFile = File(context.cacheDir, fileName)

        if (type == AttachmentType.HTML_FILE) {
            withContext(Dispatchers.IO) {
                outputFile.writeText(htmlContent, Charsets.UTF_8)
            }
            return@withContext outputFile
        }

        val webView = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            setBackgroundColor(Color.WHITE)
        }

        suspendCancellableCoroutine<Unit> { continuation ->
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    view?.postDelayed({
                        if (continuation.isActive) continuation.resume(Unit)
                    }, 400)
                }
            }
            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
        }

        val targetWidth = 800
        webView.measure(
            View.MeasureSpec.makeMeasureSpec(targetWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val contentHeight = webView.measuredHeight.coerceAtLeast(1120)
        webView.layout(0, 0, targetWidth, contentHeight)

        withContext(Dispatchers.IO) {
            when (type) {
                AttachmentType.JPEG, AttachmentType.PNG -> {
                    val bitmap = renderWebViewToBitmap(webView, targetWidth, contentHeight)
                    FileOutputStream(outputFile).use { out ->
                        val format = if (type == AttachmentType.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                        bitmap.compress(format, 92, out)
                    }
                    bitmap.recycle()
                }

                AttachmentType.IMAGE_PDF -> {
                    val bitmap = renderWebViewToBitmap(webView, targetWidth, contentHeight)
                    val pdfDocument = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(targetWidth, contentHeight, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdfDocument.finishPage(page)

                    FileOutputStream(outputFile).use { out ->
                        pdfDocument.writeTo(out)
                    }
                    pdfDocument.close()
                    bitmap.recycle()
                }

                AttachmentType.PDF -> {
                    val pdfDocument = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(targetWidth, contentHeight, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    withContext(Dispatchers.Main) {
                        webView.draw(page.canvas)
                    }
                    pdfDocument.finishPage(page)

                    FileOutputStream(outputFile).use { out ->
                        pdfDocument.writeTo(out)
                    }
                    pdfDocument.close()
                }

                else -> {}
            }
        }

        webView.destroy()
        return@withContext outputFile
    }

    private suspend fun renderWebViewToBitmap(webView: WebView, width: Int, height: Int): Bitmap =
        withContext(Dispatchers.Main) {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            webView.draw(canvas)
            bitmap
        }
}
