package com.p7m.mailsender

import android.app.Application
import android.webkit.WebView

class MailApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Essential so off-screen WebViews render full scrollable HTML documents into PDFs/Images without clipping
        WebView.enableSlowWholeDocumentDraw()
    }
}
