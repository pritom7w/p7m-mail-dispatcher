package com.p7m.mailsender

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.activation.DataHandler
import javax.activation.FileDataSource
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private var contactList: List<String> = emptyList()
    private var isSending = false

    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnStartCampaign: Button

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            contactList = parseContactsFromUri(this, it)
            tvStatus.text = "Loaded ${contactList.size} valid email addresses."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etSenderName = findViewById<EditText>(R.id.etSenderName)
        val etSubject = findViewById<EditText>(R.id.etSubject)
        val etBody = findViewById<EditText>(R.id.etBody)
        val etHtmlCode = findViewById<EditText>(R.id.etHtmlCode)
        val spinnerType = findViewById<Spinner>(R.id.spinnerAttachmentType)
        val cbAutoFileName = findViewById<CheckBox>(R.id.cbAutoFileName)
        val etCustomFileName = findViewById<EditText>(R.id.etCustomFileName)
        val etOptionalSmtpPass = findViewById<EditText>(R.id.etOptionalSmtpPass)
        val btnUploadList = findViewById<Button>(R.id.btnUploadList)
        val btnLogout = findViewById<Button>(R.id.btnLogout)

        btnStartCampaign = findViewById<Button>(R.id.btnStartCampaign)
        tvStatus = findViewById<TextView>(R.id.tvStatus)
        progressBar = findViewById<ProgressBar>(R.id.progressBar)

        spinnerType.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            AttachmentType.entries.map { it.label }
        )

        cbAutoFileName.setOnCheckedChangeListener { _, isChecked ->
            etCustomFileName.isEnabled = !isChecked
        }

        btnUploadList.setOnClickListener {
            filePickerLauncher.launch("*/*")
        }

        btnLogout.setOnClickListener {
            SessionManager.clearSession(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        btnStartCampaign.setOnClickListener {
            if (isSending) {
                isSending = false
                btnStartCampaign.text = "Start Sending"
                return@setOnClickListener
            }

            if (contactList.isEmpty()) {
                Toast.makeText(this, "Please upload your contact list (.txt or .csv)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val senderName = etSenderName.text.toString().trim()
            val subjectTemplate = etSubject.text.toString()
            val bodyTemplate = etBody.text.toString()
            val htmlTemplate = etHtmlCode.text.toString()
            val selectedType = AttachmentType.entries[spinnerType.selectedItemPosition]
            val isAutoName = cbAutoFileName.isChecked
            val customName = etCustomFileName.text.toString().trim()
            val optionalPass = etOptionalSmtpPass.text.toString().replace(" ", "").trim()

            isSending = true
            btnStartCampaign.text = "Stop Campaign"
            progressBar.max = contactList.size
            progressBar.progress = 0

            lifecycleScope.launch {
                var successCount = 0
                var failCount = 0
                val userEmail = SessionManager.getUserEmail(this@MainActivity)

                for ((index, recipient) in contactList.withIndex()) {
                    if (!isSending) break

                    tvStatus.text = "Sending ${index + 1}/${contactList.size}: $recipient"

                    val personalizedHtml = htmlTemplate.replace("{{email}}", recipient)
                    val personalizedBody = if (selectedType == AttachmentType.BODY_HTML) {
                        personalizedHtml
                    } else {
                        bodyTemplate.replace("{{email}}", recipient)
                    }
                    val personalizedSubject = subjectTemplate.replace("{{email}}", recipient)

                    val finalFileName = HtmlConverter.resolveFileName(customName, isAutoName, selectedType)
                    val attachmentFile = HtmlConverter.convertHtmlToFile(
                        context = this@MainActivity,
                        htmlContent = personalizedHtml,
                        type = selectedType,
                        fileName = finalFileName
                    )

                    // Dispatch email 1-by-1
                    val result = sendEmailThroughSmtpOrSession(
                        senderEmail = userEmail,
                        appPassword = optionalPass,
                        senderName = senderName,
                        recipientEmail = recipient,
                        subject = personalizedSubject,
                        bodyTextOrHtml = personalizedBody,
                        isBodyHtml = (selectedType == AttachmentType.BODY_HTML),
                        attachmentFile = attachmentFile
                    )

                    attachmentFile?.delete()

                    if (result.isSuccess) successCount++ else failCount++
                    progressBar.progress = index + 1
                    tvStatus.text = "Success: $successCount | Failed: $failCount (${index + 1}/${contactList.size})"

                    // Jitter delay (8 to 14 seconds) to ensure safe 1-by-1 sending
                    if (index < contactList.size - 1 && isSending) {
                        delay(Random.nextLong(8000L, 14000L))
                    }
                }

                isSending = false
                btnStartCampaign.text = "Start Sending"
                tvStatus.text = "Campaign Finished! Success: $successCount, Failed: $failCount"
            }
        }
    }

    private suspend fun sendEmailThroughSmtpOrSession(
        senderEmail: String,
        appPassword: String,
        senderName: String,
        recipientEmail: String,
        subject: String,
        bodyTextOrHtml: String,
        isBodyHtml: Boolean,
        attachmentFile: java.io.File?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.port", "587")
                put("mail.smtp.ssl.trust", "smtp.gmail.com")
            }

            val session = if (appPassword.isNotBlank()) {
                Session.getInstance(props, object : Authenticator() {
                    override fun getPasswordAuthentication(): PasswordAuthentication {
                        return PasswordAuthentication(senderEmail, appPassword)
                    }
                })
            } else {
                Session.getInstance(props)
            }

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, senderName.ifBlank { "Dispatcher" }, "UTF-8"))
                setRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail.trim()))
                setSubject(subject, "UTF-8")
            }

            val multipart = MimeMultipart()
            val bodyPart = MimeBodyPart().apply {
                if (isBodyHtml) {
                    setContent(bodyTextOrHtml, "text/html; charset=utf-8")
                } else {
                    setText(bodyTextOrHtml, "UTF-8")
                }
            }
            multipart.addBodyPart(bodyPart)

            if (attachmentFile != null && attachmentFile.exists()) {
                val attachmentPart = MimeBodyPart().apply {
                    dataHandler = DataHandler(FileDataSource(attachmentFile))
                    fileName = attachmentFile.name
                }
                multipart.addBodyPart(attachmentPart)
            }

            message.setContent(multipart)
            Transport.send(message)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseContactsFromUri(context: Context, uri: Uri): List<String> {
        val emailRegex = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
        val extracted = LinkedHashSet<String>()

        context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            lines.forEach { line ->
                emailRegex.findAll(line).forEach { match ->
                    extracted.add(match.value.lowercase())
                }
            }
        }
        return extracted.toList()
    }
}
