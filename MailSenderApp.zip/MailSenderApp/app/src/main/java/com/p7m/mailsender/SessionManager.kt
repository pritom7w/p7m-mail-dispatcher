package com.p7m.mailsender

import android.content.Context
import android.webkit.CookieManager

object SessionManager {
    private const val PREF_NAME = "p7m_session_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_USER_EMAIL = "user_email"

    fun saveLoginState(context: Context, email: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_IS_LOGGED_IN, true).putString(KEY_USER_EMAIL, email).apply()
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val hasSessionCookie = CookieManager.getInstance().getCookie("https://mail.google.com")?.isNotEmpty() == true
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false) || hasSessionCookie
    }

    fun getUserEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_USER_EMAIL, "user@gmail.com") ?: "user@gmail.com"
    }

    fun clearSession(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
    }
}
